<?php 
	
	$host = "localhost";
	$db   = "biblioteca";
	$user = "root";
	$pass = "usbw";
	
	$conn = mysqli_connect($host, $user, $pass, $db);